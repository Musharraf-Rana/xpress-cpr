{{-- <link rel="stylesheet" href="{{asset('assets/css/style.css"> --}}

<link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
<link rel="stylesheet" href="{{ asset('assets/css/mediia.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/tabletMedia.css') }}">
<link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="stylesheet" href="{{ asset('assets/css/desktopmedia.css') }}">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Open+Sans">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="{{ asset('assets/css/caresole.css') }}">

<style>
    .learnmore {
        background-color: #C4403E;
        color: #fff;
        padding: 14px 35px;
        font-size: 16px;
        border-radius: 10px;
        font-weight: 400;
        border: 0;

    }
</style>
